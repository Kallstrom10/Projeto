function checkcookieconset(){
    if (!localStorage.getItem('cookieconsent')){
    showcooknot();
    }
}

function showcooknot() {
var notification = document.getElementById('cooknot');
notification.style.display='block';
}

function hidecooknot() {
    var notification= document.getElementById('cooknot');
    notification.style.display='none';
    localStorage.setItem('cookieconsent', 'true')
}

document.getElementById('aceitarcook').addEventListener('click', function(){
 hidecooknot()
});

checkcookieconset();


